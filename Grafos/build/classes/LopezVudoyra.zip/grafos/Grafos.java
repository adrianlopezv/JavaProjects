
package grafos;
import java.util.Scanner;
public class Grafos {

    public static void main(String[] args) 
    {
    
        Scanner entrada=new Scanner(System.in);
    Scanner entradastr=new Scanner(System.in);
    int opcion=0,n=0,x,opcion2=0,bandera=0; 
    System.out.println("Ingresa el numero de vertices");
    x=entrada.nextInt();
    MatrizAdyacencias matrizadyacencias=new MatrizAdyacencias(x);
    ListaAdyacencia  listaadyacencia[] = new ListaAdyacencia[x];
    char nombre='A';
    char nombres[]=new char[x];
     String listanombres="",listadelistas="";
     
    for(int w=0;w<x;w++)
    {
    nombres[w]=nombre;
    listaadyacencia[w]=new ListaAdyacencia(nombre); 
    NodoSimple nodo=new NodoSimple(Character.toString(nombre));
    nombre++; 
    
    }
    
    for(int j=0;j<x;j++)
    {
    listanombres+=nombres[j];
    
    }
   System.out.println("1.-Grafo dirigido\n2.-Grafo no dirigido");
   opcion2=entrada.nextInt();
   switch(opcion2)
    {
       case 1:
   while(n<x)
   {  
       do
       {
       System.out.println("1.-Agregar conexion a nodos\t2.-Imprimir la matriz de adyacencias\t3.-Imprimir la lista de adyacencias\t"
               + "4.-Pasar al siguiente nodo");
       opcion=entrada.nextInt();
       switch(opcion)
       {
           case 1:
               System.out.println("Tienes "+x+" nodos\nSus nombres son:\n"+listanombres+"\nEstas en el nodo "+nombres[n]
               +"\nIngrese e nombre del nodo al que quiere conectar con el nodo actual");
               nombre=entradastr.next().charAt(0);
               nombre=Character.toUpperCase(nombre);
               int y=0,peso;
               while(nombre!=nombres[y]&&y<x-1)
               { 
                   y++;
               }
               if(nombre!=nombres[y])
               { 
               System.out.println("Ese nodo no existe");
               }
               else
               {
               System.out.println("Que peso tendrá el enlace?(Un numero menor a 1000)");
               peso=entrada.nextInt();
              boolean b= matrizadyacencias.AgregarAMat(n, y, peso,bandera);
              if(b==true)
              {
              listaadyacencia[n].insertarFinal(nombres[y]);
              }
               }
      
               break;
               
           case 2:
               System.out.println(matrizadyacencias.toString());
               break;
               
               case 3:
                   listadelistas="";
               for(int w=0;w<x;w++)
               {
               listadelistas+=listaadyacencia[w].toString()+"\n";
               }
               System.out.println(listadelistas);
               break;
               
               case 4:
                   System.out.println();
               break;
           default:
               System.out.println("Esta opcion no existe, favor de selccionar otra");
               break;
       }
       }while(opcion!=4);
   
       n++;
   }
   System.out.println("Con grafos dirigidos se puede aplicar el método de Floyd, gusta que le mostremos la ruta con menor"
           + "peso utilizando este metodo?\n1.-Si\nOtro numero para salir");
   opcion=entrada.nextInt();
   switch(opcion)
   {
       case 1:
           MetodoFloyd(matrizadyacencias,x);
           break;
           
       default:
           System.out.println("Gracias! Hasta luego");
           break;
   }
   break;
   
       case 2:
           System.out.println("Opcion en desarrollo");
           break;
       default:
           System.out.println("Opcion no valida");
           break;
    }
}
    
    
    public static void MetodoFloyd(MatrizAdyacencias matrizadyacencias,int x)
    {
        int [][]resultado;
        int bandera=0;
        MatrizAdyacencias matrizadyacenciascopia=new MatrizAdyacencias(x);
        matrizadyacenciascopia=matrizadyacencias;
         char matriznombres[][]=new char[x][x];
         char nombre;
         for(int i=0;i<x;i++)
         {
         nombre='A';
         for(int j=0;j<x;j++)
         {
         matriznombres[i][j]=nombre;
         nombre++;
         }
         }
         for(int i=0;i<x;i++)
         {
         matrizadyacenciascopia.AgregarAMat(i, i, -10,bandera);
         }
         bandera=1;
         System.out.println(matrizadyacenciascopia.toString());
       for (int k = 0; k < x; k++){
      for (int i = 0; i < x; i++){
         for (int j = 0; j < x; j++){

            if (matrizadyacenciascopia.Regresarvalor(i,k) + matrizadyacenciascopia.Regresarvalor(k,j)<
                    matrizadyacenciascopia.Regresarvalor(i,j) && matrizadyacenciascopia.Regresarvalor(i,k)!=-10 
                    && matrizadyacenciascopia.Regresarvalor(k,j)!=-10)
            {
				matrizadyacenciascopia.AgregarAMat(i, j,matrizadyacenciascopia.Regresarvalor(i, k)
                                        + matrizadyacenciascopia.Regresarvalor(k, j),bandera) ;
                                matriznombres[i][j]=matriznombres[i][k];
                                	
            }
         }
      }
    
    }
       System.out.println(matrizadyacenciascopia.toString());
       for(int w=0;w<x;w++)
       {
       for(int t=0;t<x;t++)
       {
       System.out.print(matriznombres[w][t]);
       }
       System.out.println();
       }
    }
}













