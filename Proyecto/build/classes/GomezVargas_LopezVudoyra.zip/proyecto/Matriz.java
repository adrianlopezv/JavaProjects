
package proyecto;

public interface Matriz
{
public void setMatriz();
public void setMatrizCodice();
}
