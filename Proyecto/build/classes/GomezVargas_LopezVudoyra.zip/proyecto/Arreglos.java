
package proyecto;

public interface Arreglos 
{
public void setAbecedario();
public void setAbecedarioModificado(int x);
public void setAbecedarioMayusculas();
public void setAbecedarioModificadoMinusculas(int x);
}
