package Main;
import java.util.*;
import lista.tipoLista.ListaCircular;
import lista.tipoLista.ListaSimple;
import nodo.tipoNodo.NodoDoble;

public class Menu {
    
    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
        
        int opcion = 0;
        ListaSimple listaSimple = new ListaSimple();
        ListaCircular listaCircular = new ListaCircular();
        boolean validar = false;
        
        do{
            while (!validar){
                try{
                    validar = true;
                    System.out.println("1. Lista Simple");
                    System.out.println("2. Lista Circular");
                    System.out.println("3. Finalizar programa");
            
                    System.out.print("Opcion: ");
                    opcion = entrada.nextInt();
                }catch(InputMismatchException e){
                    System.err.println("El dato no es un numero. Intente de nuevo");
                    entrada.nextLine();
                    validar = false;
                    System.out.println("");
                }
            }
            switch(opcion){
                case 1: 
                    listaSimple = opcionesListaSimple(entrada, listaSimple);
                    validar = false;
                  break;
                case 2: 
                    listaCircular = opcionesListaCircular(entrada, listaCircular);
                    validar = false;
                  break;
                case 3: System.out.println("Hasta luego.");
                  break;
                default: 
                    System.out.println("Opcion invalida.");
                    validar = false;
                  break;
            }
        }while(opcion != 3);
    }
    
    public static ListaSimple opcionesListaSimple(Scanner entrada, ListaSimple listaSimple) {
        int opcion = 0;
        boolean validar = false;
        
        do{
            while(!validar){
                try{
                    validar = true;
                    System.out.println("\n" + listaSimple);
                    System.out.println("1. Insertar");
                    System.out.println("2. Borrar");
                    System.out.println("3. Regresar al menu anterior");
            
                    System.out.print("Opcion: ");
                    opcion = entrada.nextInt();
                }catch(InputMismatchException e){
                    System.err.println("El dato no es un numero. Intente de nuevo");
                    entrada.nextLine();
                    validar = false;
                    System.out.println("");
                }
            }
            switch(opcion){
                case 1: 
                    listaSimple = insertarNodoSimple(entrada, listaSimple);
                    validar = false;
                  break;
                case 2: 
                    listaSimple = borrarNodoSimple(entrada, listaSimple);
                    validar = false;
                  break;
                case 3: 
                  break;
                default: 
                    System.out.println("Opcion invalida.");
                    validar = false;
                  break;
            }
        
        }while(opcion != 3);
        System.out.print("\n");
        return listaSimple;
    }
    
    public static ListaSimple insertarNodoSimple(Scanner entrada, ListaSimple listaSimple){
        Scanner entradaString = new Scanner(System.in);
        int opcion = 0;
        boolean validar = false;
        
        do{
            while(!validar){
                try{
                    validar = true;
                    System.out.println("\n" + listaSimple);
                    System.out.println("1. Insertar al incio");
                    System.out.println("2. Insertar al final");
                    System.out.println("3. Insertar despues de");
                    System.out.println("4. Regresar al menu anterior");
            
                    System.out.print("Opcion: ");
                    opcion = entrada.nextInt();
                }catch(InputMismatchException e){
                    System.err.println("El dato no es un numero. Intente de nuevo");
                    entrada.nextLine();
                    validar = false;
                    System.out.println("");
                }
            }
            switch(opcion){
                case 1: 
                    System.out.print("Dato del nodo a instertar: ");
                    String dato = entradaString.nextLine();
                    listaSimple.insertarInicio(new NodoDoble(dato));
                    validar = false;
                  break;
                case 2: 
                    System.out.print("Dato del nodo a instertar: ");
                    String dato1 = entradaString.nextLine();
                    listaSimple.insertarFinal(new NodoDoble(dato1));
                    validar = false;
                  break;
                case 3: 
                    System.out.print("Dato del nodo a instertar: ");
                    String dato2 = entradaString.nextLine();
                    System.out.print("Ingresa la referencia: ");
                    String referencia = entradaString.nextLine();
                    listaSimple.insertarDespuesDe(new NodoDoble(dato2), new NodoDoble(referencia));
                    validar = false;
                  break;
                case 4: 
                  break;
                default: 
                    System.out.println("Opcion invalida");
                    validar = false;
                  break;
            }
        
        }while(opcion != 4);
      return listaSimple;
    }
    
    public static ListaSimple borrarNodoSimple(Scanner entrada, ListaSimple listaSimple){
        Scanner entradaString = new Scanner(System.in);
        int opcion = 0;
        boolean validar = false;
        
        do{
            while(!validar){
                try{
                    validar = true;
                    System.out.println("\n" + listaSimple);
                    System.out.println("1. Borrar al incio");
                    System.out.println("2. Borrar al final");
                    System.out.println("3. Borrar despues de");
                    System.out.println("4. Regresar al menu anterior");
            
                    System.out.print("Opcion: ");
                    opcion = entrada.nextInt();
                }catch(InputMismatchException e){
                    System.err.println("El dato no es un numero. Intente de nuevo");
                    entrada.nextLine();
                    validar = false;
                    System.out.println("");
                }
            }
            switch(opcion){
                case 1: 
                    listaSimple.borrarInicio();
                    validar = false;
                  break;
                case 2: 
                    listaSimple.borrarFinal();
                    validar = false;
                  break;
                case 3: 
                    System.out.print("Ingresa la referencia: ");
                    String referencia = entradaString.nextLine();
                    listaSimple.borrarDespuesDe(new NodoDoble(referencia));
                    validar = false;
                  break;
                case 4: 
                  break;
                default: 
                    System.out.println("Opcion invalida");
                    validar = false;
                  break;
            }
        
        }while(opcion != 4);
      return listaSimple;
    }
    
    public static ListaCircular opcionesListaCircular(Scanner entrada, ListaCircular listaCircular) {
        int opcion = 0;
        boolean validar = false;
        
        do{
            while(!validar){
                try{
                    validar = true;
                    System.out.println("\n" + listaCircular);
                    System.out.println("1. Insertar");
                    System.out.println("2. Borrar");
                    System.out.println("3. Regresar al menu anterior");
            
                    System.out.print("Opcion: ");
                    opcion = entrada.nextInt();
                }catch(InputMismatchException e){
                    System.err.println("El dato no es un numero. Intente de nuevo");
                    entrada.nextLine();
                    validar = false;
                    System.out.println("");
                }
            }
            switch(opcion){
                case 1: 
                    listaCircular = insertarNodoCircular(entrada, listaCircular);
                    validar = false;
                  break;
                case 2: 
                    listaCircular = borrarNodoCircular(entrada, listaCircular);
                    validar = false;
                  break;
                case 3: 
                  break;
                default: 
                    System.out.println("Opcion invalida.");
                    validar = false;
                  break;
            }
        
        }while(opcion != 3);
        System.out.print("\n");
        
        return listaCircular;
    }
    
    public static ListaCircular insertarNodoCircular(Scanner entrada, ListaCircular listaCircular){
        Scanner entradaString = new Scanner(System.in);
        int opcion = 0;
        boolean validar = false;
        
        do{
            while(!validar){
                try{
                    validar = true;
                    System.out.println("\n" + listaCircular);
                    System.out.println("1. Insertar al incio");
                    System.out.println("2. Insertar al final");
                    System.out.println("3. Insertar despues de");
                    System.out.println("4. Regresar al menu anterior");
            
                    System.out.print("Opcion: ");
                    opcion = entrada.nextInt();
                }catch(InputMismatchException e){
                    System.err.println("El dato no es un numero. Intente de nuevo");
                    entrada.nextLine();
                    validar = false;
                    System.out.println("");
                }
            }
            switch(opcion){
                case 1: 
                    System.out.print("Dato del nodo a instertar: ");
                    String dato = entradaString.nextLine();
                    listaCircular.insertarInicio(new NodoDoble(dato));
                    validar = false;
                  break;
                case 2: 
                    System.out.print("Dato del nodo a instertar: ");
                    String dato1 = entradaString.nextLine();
                    listaCircular.insertarFinal(new NodoDoble(dato1));
                    validar = false;
                  break;
                case 3: 
                    System.out.print("Dato del nodo a instertar: ");
                    String dato2 = entradaString.nextLine();
                    System.out.print("Ingresa la referencia: ");
                    String referencia = entradaString.nextLine();
                    listaCircular.insertarDespuesDe(new NodoDoble(dato2), new NodoDoble(referencia));
                    validar = false;
                  break;
                case 4: 
                  break;
                default: 
                    System.out.println("Opcion invalida");
                    validar = false;
                  break;
            }
        
        }while(opcion != 4);
      return listaCircular;
    }
    
    public static ListaCircular borrarNodoCircular(Scanner entrada, ListaCircular listaCircular){
        Scanner entradaString = new Scanner(System.in);
        int opcion = 0;
        boolean validar = false;
        
        do{
            while(!validar){
                try{
                    validar = true;
                    System.out.println("\n" + listaCircular);
                    System.out.println("1. Borrar al incio");
                    System.out.println("2. Borrar al final");
                    System.out.println("3. Borrar despues de");
                    System.out.println("4. Regresar al menu anterior");
            
                    System.out.print("Opcion: ");
                    opcion = entrada.nextInt();
                }catch(InputMismatchException e){
                    System.err.println("El dato no es un numero. Intente de nuevo");
                    entrada.nextLine();
                    validar = false;
                    System.out.println("");
                }
            }
            switch(opcion){
                case 1: 
                    listaCircular.borrarInicio();
                    validar = false;
                  break;
                case 2: 
                    listaCircular.borrarFinal();
                    validar = false;
                  break;
                case 3: 
                    System.out.print("Ingresa la referencia: ");
                    String referencia = entradaString.nextLine();
                    listaCircular.borrarDespuesDe(new NodoDoble(referencia));
                    validar = false;
                  break;
                case 4: 
                  break;
                default: 
                    System.out.println("Opcion invalida");
                    validar = false;
                  break;
            }
        
        }while(opcion != 4);
      return listaCircular;
    }
}