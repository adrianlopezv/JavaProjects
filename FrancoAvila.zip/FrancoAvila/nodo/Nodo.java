package nodo;
    
public class Nodo {
    protected String info;	
    protected Nodo nextNodo;

    public Nodo(String info){
	this.info = info;
    }
	
    public void setNextNodo(Nodo nodo){
	this.nextNodo = nodo;
    }
    
    public Nodo getNextNodo(){
	return this.nextNodo;
    }
    
    public String getInfo() {
        return this.info;
    } 
}