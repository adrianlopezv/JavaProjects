package lista;
import nodo.tipoNodo.NodoDoble;

public interface Lista {
    
    public void insertarInicio(NodoDoble nodo);
    public void borrarInicio();
    public void insertarFinal(NodoDoble nodo);
    public void borrarFinal();
    public void insertarDespuesDe(NodoDoble nodo, NodoDoble referencia);
    public void borrarDespuesDe(NodoDoble referencia);
    public String toString();
    
}