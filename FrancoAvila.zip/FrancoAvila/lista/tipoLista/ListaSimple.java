package lista.tipoLista;
import nodo.tipoNodo.NodoDoble;
import lista.Lista;

public class ListaSimple implements Lista{
    private NodoDoble nodoRaiz;
    
    public void insertarInicio(NodoDoble nodo){
        if (this.nodoRaiz == null){
            this.nodoRaiz = nodo;
        } else{
            nodo.setNextNodo(this.nodoRaiz);
            this.nodoRaiz.setPreviewNodo(nodo);
            this.nodoRaiz = nodo;
        }
    }
    
    public void borrarInicio(){
        if (this.nodoRaiz == null){
            System.out.println("Es necesario crear una lista para realizar esta operacion.");
        } else{
            NodoDoble nodoFinal = this.nodoRaiz;
            while(nodoFinal.getNextNodo() != null){
                nodoFinal = (NodoDoble)nodoFinal.getNextNodo();
            }
            if(this.nodoRaiz == nodoFinal){
                System.out.println("Elemento unico. No es posible realizar el borrado.");
            } else{
                NodoDoble nodoAux = nodoRaiz;
                nodoRaiz = (NodoDoble)nodoRaiz.getNextNodo();
                nodoAux.setNextNodo(null);
                nodoRaiz.setPreviewNodo(null);
            }
        }
    }
    
    public void insertarFinal(NodoDoble nodo){
        if (this.nodoRaiz == null){
            this.nodoRaiz = nodo;
        } else{
            NodoDoble nodoAuxiliar = nodoRaiz; 
            while(nodoAuxiliar.getNextNodo() != null){
                nodoAuxiliar = (NodoDoble)nodoAuxiliar.getNextNodo();
            }
            nodoAuxiliar.setNextNodo(nodo);
            nodo.setPreviewNodo(nodoAuxiliar);
        }
    }
    
    public void borrarFinal(){
    if (this.nodoRaiz == null){
            System.out.println("Es necesario crear una lista para realizar esta operacion.");
        } else{
            NodoDoble nodoFinal = this.nodoRaiz;
            while(nodoFinal.getNextNodo() != null){
                nodoFinal = (NodoDoble)nodoFinal.getNextNodo();
            }
            if(this.nodoRaiz == nodoFinal){
                System.out.println("Elemento unico. No es posible realizar el borrado.");
            } else{
                NodoDoble nodoAux = nodoRaiz; 
                while(nodoAux.getNextNodo().getNextNodo() != null){
                    nodoAux = (NodoDoble)nodoAux.getNextNodo();
                }
                ((NodoDoble)nodoAux.getNextNodo()).setPreviewNodo(null);
                nodoAux.setNextNodo(null);
            }
        }
    }
    
    public void insertarDespuesDe(NodoDoble nodo, NodoDoble referencia){
        if (this.nodoRaiz == null){
            System.out.println("Es necesario crear una lista para realizar esta operacion.");
        } else{
            NodoDoble nodoAuxiliar = nodoRaiz;
            while(!nodoAuxiliar.getInfo().equals(referencia.getInfo()) && nodoAuxiliar.getNextNodo() != null){
                nodoAuxiliar = (NodoDoble) nodoAuxiliar.getNextNodo();
            }
            if(nodoAuxiliar.getInfo().equals(referencia.getInfo())){
                if(nodoAuxiliar.getNextNodo() == null){
                    insertarFinal(nodo);
                } else{
                    nodo.setNextNodo(nodoAuxiliar.getNextNodo());
                    ((NodoDoble)nodoAuxiliar.getNextNodo()).setPreviewNodo(nodo);
                    nodoAuxiliar.setNextNodo(nodo);
                    nodo.setPreviewNodo(nodoAuxiliar);
                }
            } else{
                System.out.println("Esta referencia es invalida.");
            }
        }
    }
    
    public void borrarDespuesDe(NodoDoble referencia){
        if (this.nodoRaiz == null){
            System.out.println("Es necesario crear una lista para realizar esta operacion.");
        } else{
            NodoDoble nodoAnterior = nodoRaiz;
            NodoDoble nodoAux= (NodoDoble)nodoAnterior.getNextNodo();
            if(nodoAnterior.getNextNodo() == null){
                System.out.println("Elemento unico. No es posible realizar el borrado.");
            } else{
                while(!nodoAnterior.getInfo().equals(referencia.getInfo()) && nodoAux.getNextNodo() != null){
                    nodoAnterior = nodoAux; 
                    nodoAux = (NodoDoble)nodoAnterior.getNextNodo();
                }
                if(nodoAux.getNextNodo() == null){
                    System.out.println("Esta referencia es invalida.");
                } else{
                    if(nodoAnterior.getInfo().equals(referencia.getInfo())){
                        nodoAnterior.setNextNodo(nodoAux.getNextNodo());
                        ((NodoDoble)nodoAux.getNextNodo()).setPreviewNodo(nodoAnterior);
                        nodoAux.setNextNodo(null);
                        nodoAux.setPreviewNodo(null);
                    } else{
                        System.out.println("Esta referencia es invalida.");
                    }
                }
            }
        }
    }
    
    public String toString(){
        String listaString = "" ;
        
        if (this.nodoRaiz == null){
            listaString = "Lista vacia";
        } else{
            NodoDoble nodoAux = this.nodoRaiz;
            while(nodoAux != null){
                listaString += nodoAux.getInfo() + " ";
                nodoAux = (NodoDoble)nodoAux.getNextNodo();
            }
        }
        return listaString;
    }
}