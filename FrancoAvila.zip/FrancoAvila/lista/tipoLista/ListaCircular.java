package lista.tipoLista;
import nodo.tipoNodo.NodoDoble;
import lista.Lista;

public class ListaCircular implements Lista {
    private NodoDoble nodoRaiz;
    private NodoDoble nodoFinal;
    
    public void insertarInicio(NodoDoble nodo){
        if (this.nodoRaiz == null){
            this.nodoRaiz = nodo;
            this.nodoRaiz.setPreviewNodo(this.nodoRaiz);
            this.nodoRaiz.setNextNodo(this.nodoRaiz);
            this.nodoFinal = this.nodoRaiz;
        } else{
            nodo.setNextNodo(this.nodoRaiz);
            this.nodoRaiz.setPreviewNodo(nodo);
            this.nodoRaiz = nodo;
            this.nodoRaiz.setPreviewNodo(this.nodoFinal);
            this.nodoFinal.setNextNodo(this.nodoRaiz);
        }
    }
    
    public void borrarInicio(){
        if (this.nodoRaiz == null){
            System.out.println("Es necesario crear una lista para realizar esta operacion.");
        } else{
            if(this.nodoRaiz == this.nodoFinal){
                System.out.println("Elemento unico. No es posible realizar el borrado.");
            } else{
                NodoDoble nodoAux = this.nodoRaiz;
                this.nodoRaiz = ((NodoDoble)this.nodoRaiz.getNextNodo());
                nodoAux.setNextNodo(null);
                nodoAux.setPreviewNodo(null);
                nodoRaiz.setPreviewNodo(nodoFinal);
                this.nodoFinal.setNextNodo(this.nodoRaiz);
            }
        }
    }
    
    public void insertarFinal(NodoDoble nodo){
        if (this.nodoRaiz == null){
            insertarInicio(nodo);
        } else{
            this.nodoFinal.setNextNodo(nodo);
            nodo.setPreviewNodo(this.nodoFinal);
            this.nodoFinal = nodo;
            this.nodoRaiz.setPreviewNodo(this.nodoFinal);
            this.nodoFinal.setNextNodo(this.nodoRaiz);
        }
    }
    
    public void borrarFinal(){
        if (this.nodoRaiz == null){
            System.out.println("Es necesario crear una lista para realizar esta operacion.");
        } else{
            if(nodoRaiz == nodoFinal){
                System.out.println("Elemento unico. No es posible realizar el borrado.");
            } else{
                NodoDoble nodoAux = nodoRaiz; 
                while(nodoAux.getNextNodo() != nodoFinal){
                    nodoAux = (NodoDoble)nodoAux.getNextNodo();
                }
                nodoFinal.setNextNodo(null);
                nodoFinal.setPreviewNodo(null);
                this.nodoFinal = nodoAux;
                this.nodoFinal.setNextNodo(this.nodoRaiz);
                this.nodoRaiz.setPreviewNodo(nodoFinal);
            }
        }
    }
    
    public void insertarDespuesDe(NodoDoble nodo, NodoDoble referencia){
        if (this.nodoRaiz == null){
            System.out.println("Es necesario crear una lista para realizar esta operacion.");
        } else{
            NodoDoble nodoAuxiliar = nodoRaiz;
            if(referencia.getInfo().equals(nodoFinal.getInfo())){
                insertarFinal(nodo);
                //nodoFinal.setNextNodo(nodo);
            } else{
                while(!nodoAuxiliar.getInfo().equals(referencia.getInfo()) && !nodoAuxiliar.getInfo().equals(nodoFinal.getInfo())){
                    nodoAuxiliar = (NodoDoble)nodoAuxiliar.getNextNodo();
                }
                if(nodoAuxiliar.getInfo().equals(referencia.getInfo())){
                    nodo.setNextNodo(nodoAuxiliar.getNextNodo());
                    ((NodoDoble)nodoAuxiliar.getNextNodo()).setPreviewNodo(nodo);
                    nodoAuxiliar.setNextNodo(nodo);
                    nodo.setPreviewNodo(nodoAuxiliar);
                } else{
                    System.out.println("Esta referencia es invalida.");
                }
            }
        }
    }
    
    public void borrarDespuesDe(NodoDoble referencia){
        if (this.nodoRaiz == null){
            System.out.println("Es necesario crear una lista para realizar esta operacion.");
        } else{
            if(this.nodoRaiz == this.nodoFinal){
                System.out.println("Elemento unico. No es posible realizar el borrado.");
            } else{
                NodoDoble nodoAnterior = nodoRaiz;
                NodoDoble nodoAux = (NodoDoble)nodoAnterior.getNextNodo();
                while(!nodoAnterior.getInfo().equals(referencia.getInfo()) && nodoAux != nodoRaiz){
                    nodoAnterior = nodoAux; 
                    nodoAux = (NodoDoble)nodoAnterior.getNextNodo();
                }
                if(nodoFinal.getInfo().equals(referencia.getInfo())){
                    borrarInicio();
                } else{
                    if(nodoAux.getNextNodo() == nodoRaiz){
                        borrarFinal();
                    } else{
                        if(nodoAnterior.getInfo().equals(referencia.getInfo())){
                            nodoAnterior.setNextNodo(nodoAux.getNextNodo());
                            ((NodoDoble)nodoAux.getNextNodo()).setPreviewNodo(nodoAnterior);
                            nodoAux.setNextNodo(null);
                            nodoAux.setPreviewNodo(null);
                        } else{
                            System.out.println("Esta referencia es invalida.");
                        }
                    }
                }
            }
        }
    }
    
    public String toString(){
        String listaString = "" ;
        
        if (this.nodoRaiz == null){
            listaString = "Lista vacia";
        } else{
            NodoDoble nodoAux = this.nodoRaiz;
            while(!nodoAux.getInfo().equals(nodoFinal.getInfo())){
                listaString += nodoAux.getInfo() + " ";
                nodoAux = (NodoDoble)nodoAux.getNextNodo();
            }
            listaString += nodoFinal.getInfo() + " ";
        }
        return listaString;
    }
}