
package practica1;


public class Nombre
{
    private String nombrepila;
    private String apellidopaterno;
    private String apellidomaterno;

    /**
     * @return the nombrepila
     */
    public String getNombrepila() {
        return nombrepila;
    }

    /**
     * @param nombrepila the nombrepila to set
     */
    public void setNombrepila(String nombrepila) {
        this.nombrepila = nombrepila;
    }

    /**
     * @return the apellidopaterno
     */
    public String getApellidopaterno() {
        return apellidopaterno;
    }

    /**
     * @param apellidopaterno the apellidopaterno to set
     */
    public void setApellidopaterno(String apellidopaterno) {
        this.apellidopaterno = apellidopaterno;
    }

    /**
     * @return the apellidomaterno
     */
    public String getApellidomaterno() {
        return apellidomaterno;
    }

    /**
     * @param apellidomaterno the apellidomaterno to set
     */
    public void setApellidomaterno(String apellidomaterno) {
        this.apellidomaterno = apellidomaterno;
    }
    
    
}
