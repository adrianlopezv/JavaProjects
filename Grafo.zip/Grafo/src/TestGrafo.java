//Proyecto Matriz y lista de adyacencia 
//Grupo 400 Biomedica
//Jose Angel Armendariz Martinez
//16/05/2017
//Laura Marina Bernal Zavala

//import java.util.Random;
import java.util.Scanner;

public class TestGrafo {

	public static void main(String[] args) {
		MatrizAdyacencia mAdy = new MatrizAdyacencia(3);
		ListaAdyacencia lAdy = new ListaAdyacencia();
		Scanner entrada = new Scanner(System.in);
		int o = 0;
		int opc = 0;
		do{
			System.out.println("Hola :V");
			System.out.println("1. Dar de alta el grafo");
			System.out.println("2. Generar ruta mas corta");
			System.out.println("3. Salir");
			o = entrada.nextInt();
			switch(o){
			case 1:
		do{
			System.out.println("1. Matriz de adyacencia");
			System.out.println("2. Lista de adyacencia");
			System.out.println("3. Salir");
			opc = entrada.nextInt();
			switch(opc){
			case 1:
				int opc1 = 0;
				do{
					System.out.println("1. Llenado e impresion de matriz");
					System.out.println("2. Verificar conexiones entre los nodos");
					System.out.println("3. Salir");
					opc1 = entrada.nextInt();
					switch(opc1){
					case 1:
						System.out.println("De cuantos nodos sera el grafo?");
						int cuantos = entrada.nextInt();
						mAdy = new MatrizAdyacencia(cuantos);
						int i = 0;
						ArbolBinario arbol = new ArbolBinario();
						while(i < 50){
							int random = (int) (Math.random()*50+1);
							arbol.insertarNodo(random);
							i++;
						}
						mAdy.Llenado(arbol);
						mAdy.Imprimir();
						//mAdy.ImprimirCostos();
						break;
					case 2:
						//mAdy.VerificarCon();
						break;
					}
				}while(opc1 < 3);
			break;
			case 2: 
				lAdy = new ListaAdyacencia(mAdy);/* = new ListaAdyacencia(1);*/
				int opc2 = 0;
				do{
					System.out.println("1. Impresion de la lista");
					System.out.println("2. Verificar conexiones entre los nodos");
					System.out.println("3. Salir");
					opc2 = entrada.nextInt();
					switch(opc2){
					case 1:
						//System.out.println("De cuantos nodos sera la lista?");
						//int cuantos1 = entrada.nextInt();
						/*ListaAdyacencia*/ //lAdy = new ListaAdyacencia(mAdy);
						//lAdy.Llenado(mAdy.getMatriz());
						//lAdy.Imprimir();
						break;
					case 2:
						lAdy.VerificarCon();
						break;
					}
				}while(opc2 < 3);
				break;
			}
		}while(opc <= 2);
		break;
			case 2:
				mAdy.RutaCorta();
				//mAdy.ImprimirRutaMin();
				break;
		}
	}while(o <= 2);
	}
}
