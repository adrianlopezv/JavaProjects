//Proyecto Matriz y lista de adyacencia 
//Grupo 400 Biomedica
//Jose Angel Armendariz Martinez
//16/05/2017
//Laura Marina Bernal Zavala

import java.util.Scanner;
/**
 * La clase ListaAdyacencia permite crear un arreglo de tipo ListaSimple en el cual se almacenan la informacion de cada nodo y sus conexiones
 * con los demas
 * @author JoseAngel
 *
 */
public class ListaAdyacencia{
	/**
	 * Sus atributos son el arreglo de ListasSimples y el int que definira el tama�o del arreglo
	 */
		private ListaSimple[] arreglo;
		private int cuantosNodos;
		
		public ListaAdyacencia(){
			
		} 
		/**
		 * Constructor por medio del cual se permiten crear los objetos de tipo ListaAdyacencia,
		 * en este le establece el tama�o al arreglo de ListaSimple
		 * @param cuantosNodos Dato de tipo int que establece el tama�o del arreglo, se pide al usuario en el main
		 */
		public ListaAdyacencia(MatrizAdyacencia mAdy){
			//System.out.println(" " + mAdy.getCuantosNodos());
			this.cuantosNodos = mAdy.getCuantosNodos();
			arreglo = new ListaSimple[cuantosNodos];
		}
		/**
		 * Metodo por medio del cual se puede llenar el arreglo con la info de los nodos y a su vez, cada casilla del arreglo tiene una lista
		 * en la cual se almacena las conexiones de los nodos
		 */
		
		/*public void Llenado(){
			int k = 1;
			Scanner entrada = new Scanner(System.in);
			for(int i = 0; i < this.cuantosNodos; i++){
				System.out.println("Dame la info del nodo " + k);
				String info = entrada.nextLine();
				NodoSimple noodle = new NodoSimple(info);
				ListaSimple lista = new ListaSimple(noodle);
				System.out.println("Escribe las letras de los nodos con los que se conecta el nodo " + k);
				String conexiones = entrada.nextLine();
				for(int j = 0; j < conexiones.length(); j++){
					char caracter = conexiones.charAt(j);
					String CadDeCaracter = " " + caracter;
					lista.insercionAlFinal(CadDeCaracter);
				}
				arreglo[i] = lista;
				k++;
			}
		}*/
		public void Llenado(int[][] matriz){
			for(int i = 0; i < this.cuantosNodos; i++){
				NodoSimple noodle = new NodoSimple(String.valueOf(matriz[0][i]));
				ListaSimple lista = new ListaSimple(noodle);
				arreglo[i] = lista;
			}
			
			for(int i = 0; i < this.cuantosNodos; i++){
				for(int j = 0; j < this.cuantosNodos; j++){
					if(arreglo[i].getRaiz().getInformacion().equals(matriz[j][0])){
						for(int k = 0; k < this.cuantosNodos ; k++){
							if(matriz[i+1][k] == 1){
								arreglo[i].insercionAlFinal(String.valueOf(matriz[0][k]));
							}
						}
					}
				}
			}
		}
		
		public void VerificarCon(){
			Scanner entrada = new Scanner(System.in);
			int opc = 0;
			do{
				System.out.println("1. Checar si dos nodos estan conectados");
				System.out.println("2. Salir");
				opc = entrada.nextInt();
				switch(opc){
				case 1:
					int band = 0;
					entrada.nextLine();
					System.out.println("(Escribe la info correspondiente al 1er. nodo) El nodo:");
					String info = entrada.nextLine();
					System.out.println("(Escribe la info correspondiente al 2do. nodo) Se conecta con??:");
					String info1 = entrada.nextLine();
					for(int i = 0; i < this.cuantosNodos; i++){
						if(arreglo[i].getRaiz().getInformacion().equals(info)){
							NodoSimple noodleAux = arreglo[i].getRaiz();
							while(noodleAux.getDerNodo() != null){
								noodleAux = noodleAux.getDerNodo();
								if(noodleAux.getInformacion().compareTo(" " + info1) == 0){
									System.out.println("Si estan conectados");
									band = 1;
								}
							}
						}
					}
					if(band == 0){
					System.out.println("No estan conectados :'c");
					}
				}
			}while(opc < 2);
		}
		
		/**
		 * Metodo que complementado con el toString de ListaSimple, permite imprimir el arreglo completo
		 */
		public void Imprimir(){
			for(int i = 0; i < this.cuantosNodos; i++){
				System.out.println(" " + arreglo[i] + " ");
			}
		}
		
		public ListaSimple[] getArreglo(){
			return arreglo;
		}
	}
