//Proyecto Matriz y lista de adyacencia 
//Grupo 400 Biomedica
//Jose Angel Armendariz Martinez
//16/05/2017
//Laura Marina Bernal Zavala

import java.util.Scanner;
/**
 * La clase MatrizAdyacencia permite crear una matriz en la cual se representan las conexiones que hay entre los nodos de un grafo 
 * a traves de valores booleanos (1 � 0)
 * @author JoseAngel
 *
 */

public class MatrizAdyacencia {
	/**
	 * Los atributos de esta clase son una matriz de tipo string en donde se almacenaran las conexiones de los nodos, tambien se mostraran
	 * a manera de encabezados de la matriz la info correspondiente a cada nodo
	 * Tambien se tiene como atributo un dato de tipo int, el cual sirve para establecer las dimensiones de la matriz
	 */
	private String [] info;
	private int[][] Matriz;
	private int cuantosNodos;
	private int[][] M_ruta_min;
	private int[] costos;
	/**
	 * Constructor que permite crear objetos de tipo MatrizAdyacencia declarando ya las dimensiones de la matriz
	 * @param cuantosNodos Tama�o de la matriz. Se le pide al usuario en el test
	 */
	
	public MatrizAdyacencia(int cuantosNodos){
		this.cuantosNodos = cuantosNodos;
		info = new String[this.cuantosNodos];
		Matriz = new int[this.cuantosNodos][this.cuantosNodos];
		M_ruta_min = new int[this.cuantosNodos][this.cuantosNodos];
		costos = new int[9999];
	}
	
	public int[] getCostos(){
		return this.costos;
	}
	
	public int getCuantosNodos(){
		return this.cuantosNodos;
	}
	
	/**
	 * Metodo en el cual primero se inicializa la matriz con ceros "0", despues se le pregunta al usuario por la informacion correspondiente
	 * a cada nodo y se va asignando esta informacion en respectivo lugar del encabezado, una vez que se tiene la matriz con ceros y encabezados
	 * se le pide al usuario que introduzca las conexiones de los nodos, se leen en un string completo, se separan por caracter y se van analizando
	 * uno por uno para saber cuando y en donde es necesario colocar un "1" en la matriz 
	 */
	
	public void Llenado(ArbolBinario arbol){
		int i,j,k = 1;
		int qwe = 1;
		int u = 0;
		Scanner entrada = new Scanner(System.in);
		for(i = 0;i < this.cuantosNodos; i++){
			for(j = 0;j < this.cuantosNodos; j++){
				Matriz[i][j] = 0;
			}
		}
		for(i = 0; i < this.cuantosNodos; i++){
			for(j = 0; j < this.cuantosNodos; j++){
			if(i == 0){
				System.out.println("Dame la informacion del nodo " + k);
				String dato = entrada.nextLine();
				this.info[j] = dato;
				k++;
					}
				}
			}
		for(i = 0; i < this.cuantosNodos; i++){
			for(j = 0; j < this.cuantosNodos; j++){
				if(i != j){
					System.out.println("El nodo " + info[i] + " se conecta con " + info[j] + " ?");
					System.out.println("1. Si");
					System.out.println("2. No");
					int r = entrada.nextInt();
					switch(r){
					case 1:
						int a = 0;
						Matriz[i][j] = 1;
						while( a == 0){
							int random = (int) (Math.random()*50+1);
							if(arbol.buscar(random) == true){
								if(costos[u] == 0){
									costos[u] = random;
									a = 1;
								}else{
									do{
										u++;
									}while(costos[u] != 0);
									costos[u] = random;
									a = 1;
								}
							arbol.borrar(arbol.getRaiz(), random);
							}
						}
						break;
					case 2:
						Matriz[i][j] = 0;
						break;
					}
				}
			}
	}
}

	public void RutaCorta(){
		int k = 0;
		int aux = 0;
		int base = 0;
		int vector = info.length;
		//int[][] M_ruta_min = new int[this.cuantosNodos][this.cuantosNodos];
		int[][] Mcostos = new int[this.cuantosNodos][this.cuantosNodos];
		int[][] M1 = new int[this.cuantosNodos][this.cuantosNodos];
		int[][] M2 = new int[this.cuantosNodos][this.cuantosNodos];
		System.out.println("Matriz de costos");
		for(int i = 0; i < this.cuantosNodos; i++){
			for(int j = 0; j < this.cuantosNodos; j++){
				Mcostos[0][0] = 0;
				if(Matriz[i][j] == 1){
					Mcostos[i][j] = costos[k];
					k++;
				}else{
				if(i == j){
					Mcostos[i][j] = 0; 
					}else{
						Mcostos[i][j] = 999;
					}
				}
				System.out.print("\t" + Mcostos[i][j] + "\t");
			}
			System.out.print("\n");
		}
		
		M1 = Mcostos;
		M2 = Mcostos;
		
		System.out.println("\n\nMatriz de ruta minima");
		
		for(int i = 0; i < this.cuantosNodos; i++){
			M1[i][base] = 999; 
		}for(int i = 0; i < this.cuantosNodos; i++){
			M2[i][base] = 0; 
		}
		
		do{
			int cont = 0;
			int minimo = 999;
				for(int j = 0; j < this.cuantosNodos; j++){
					if(M1[base][j] < minimo){
						minimo = M2[base][j];
						cont += 1 ;
					}
				}
				for(int i = 0; i < this.cuantosNodos; i++){
						M2[base][i] = Mcostos[cont][i];
						M1[base][i] = Mcostos[cont][i];
				}
				for(int i = 0; i < this.cuantosNodos; i++){
					M2[i][base] = minimo;
				}
				for(int i = 0; i < this.cuantosNodos; i++){
					M1[i][base] = 999; 
				}
			
				base++;
			}while(base < vector);
		for(int i = 0; i < this.cuantosNodos; i++){
			for(int j = 0; j < this.cuantosNodos; j++){
				System.out.print("\t" + M2[i][j] + "\t");
			}
			System.out.print("\n");
		}
		
		/*for(int i = 0; i < 1; i++){
			for(int j = 0; j < this.cuantosNodos; j++){
				M_ruta_min[i][j] = Mcostos[i][j];
				System.out.print("\t" + M_ruta_min[i][j] + "\t");
			}
			System.out.print("\n");
		}
		//int minimo = 150;
		int i, pka;
		for(i = 0, pka = 1; i < this.cuantosNodos && pka < this.cuantosNodos; i++,pka++){
		int minimo = 150;
			for(int j = 0; j < this.cuantosNodos; j++){
				if(M_ruta_min[i][j] < minimo && M_ruta_min[i][j] != 0){
					minimo = M_ruta_min[i][j];
					//System.out.println("\t\t" + minimo + "\t\t");
					for(int pk = 0; pk < this.cuantosNodos; pk ++){
						M_ruta_min[pka][pk] = Mcostos[j][pk] + minimo;
						System.out.print("\t" + M_ruta_min[pka][pk]);
					}
					System.out.print("\n");
				}
			}
		}
		/*int apa = 1;
		for(int i = 0; i < this.cuantosNodos; i++){
			 //minimo = 150;
			for(int j = 0; j < this.cuantosNodos; j++){
				//int pka = 1;
				//String M_ruta = M_ruta_min[i][j]; 
				if(M_ruta_min[i][j] < minimo && M_ruta_min[i][j] != 0){
					minimo = M_ruta_min[i][j];
					System.out.println("\t\t" + minimo + "\t\t");
					if(M_ruta_min[i][j] == minimo){
						//i = j;
						for(int pka = apa; pka <= apa; pka ++){
						for(int p = 0; p < this.cuantosNodos; p++){
						M_ruta_min[pka][p] = Mcostos[j][p] + minimo;
						}
						}
						apa = apa + 1;
					//System.out.println("\t\t\t\n" + minimo + "\t\t");
				}
			}
			//minimo = 150;
		}
			//minimo = 1000;
		}*/
		
		
		/*for(i = 0; i < this.cuantosNodos; i++){
			for(int j = 0; j < this.cuantosNodos; j++){
				System.out.print(" " + M_ruta_min[i][j] + " ");
			}
			System.out.println("\n");
		}*/
	}
		
	/**
	 * Metodo que recorre la matriz por completo y conforme recorre imprime
	 */
	
	public void Imprimir(){
		int i,j;
		for(i = 0;i < this.cuantosNodos; i++){
			for(j = 0;j < this.cuantosNodos; j++){
				System.out.print(" " + Matriz[i][j] + " ");
			}
			System.out.print("\n");
		}
	}
	
	/*public void ImprimirRutaMin(){
			int i,j;
			for(i = 0;i < this.cuantosNodos+1; i++){
				for(j = 0;j < this.cuantosNodos+1; j++){
					System.out.print(" " + M_ruta_min[i][j] + " ");
				}
				System.out.print("\n");
			}
		}*/
}
