public class ArbolBinario{
	/**
	 * La clase ArbolBinario tiene como �nico atributo a raiz, que es de tipo nodo
	 */
	private NodoSimple raiz;
	/**
	 * Metodo que regresa la raiz del arbol
	 * @return raiz 
	 */
	public NodoSimple getRaiz(){
		return this.raiz;
	}
	/**
	 * M�todo que manda a llamar al metodo recursivo insertarNodoRecursivo para insertar un dato nuevo en el arbol  
	 * @param info
	 */
	
	public void insertarNodo(int info){
		this.raiz = insertarNodoRecursivo(this.raiz,info);
	}
	/**
	 * M�todo recursivo que recibe al nodo raiz del arbol junto con la informacion nueva a insertar
	 * Te permite insertar un nuevo dato al arbol, haciendolo de manera ordenada para que no se desbalancee el arbol
	 * @param otraRaiz nodo raiz el cual es mandado por el metodo insertarNodo
	 * @param info dato nuevo de tipo int que se va a insertar en el arbol
	 * @return otraRaiz
	 */
	
	private NodoSimple insertarNodoRecursivo(NodoSimple otraRaiz, int info){
		if(otraRaiz != null){
			if(otraRaiz.getInfo() > info){
				if(otraRaiz.getIzqNodo() == null){
					otraRaiz.setIzqNodo(new NodoSimple(info));
				}else{
					insertarNodoRecursivo(otraRaiz.getIzqNodo(),info);
				}
			}else{
				if(otraRaiz.getDerNodo() == null){
					otraRaiz.setDerNodo(new NodoSimple(info));
				}else{
					insertarNodoRecursivo(otraRaiz.getDerNodo(),info);
				}
			}
		}else{
			otraRaiz = new NodoSimple(info);
		}
		return otraRaiz;
	}
	/**
	 * Metodo recursivo que imprime el arbol siguiendo el formato del orden "preOrden", es decir, raiz, lado izquierdo, lado derecho
	 * @param otraRaiz nodoRaiz del arbol
	 */
	
	public void preOrden (NodoSimple otraRaiz){
		if(otraRaiz != null && otraRaiz.getInfo() != -999){
			System.out.print(otraRaiz.getInfo() + ",");
			preOrden(otraRaiz.getIzqNodo());
			preOrden(otraRaiz.getDerNodo());
		}
	}
	/**
	 * Metodo recursivo que imprime el arbol siguiendo el formato del orden "InOrden", es decir, lado izquierdo, raiz, lado derecho
	 * @param otraRaiz nodoRaiz del arbol
	 */
	
	public void InOrden (NodoSimple otraRaiz){
		if(otraRaiz != null && otraRaiz.getInfo() != -999){
			InOrden(otraRaiz.getIzqNodo());
			System.out.print(otraRaiz.getInfo() + ",");
			InOrden(otraRaiz.getDerNodo());
		}
	}
/**
	 * Metodo recursivo que imprime el arbol siguiendo el formato del orden "postOrden", es decir, lado izquierdo, lado derecho, raiz
	 * @param otraRaiz nodoRaiz del arbol
	 */
	
	public void postOrden (NodoSimple otraRaiz){
		if(otraRaiz != null && otraRaiz.getInfo() != -999){
			postOrden(otraRaiz.getIzqNodo());
			postOrden(otraRaiz.getDerNodo());
			System.out.print(otraRaiz.getInfo() + ",");
		}
	}
	/**
	 * Metodo recursivo que te permite saber si la informacion que introduces existe en el nodo
	 * @param raiz Nodo raiz del arbol
	 * @param info informacion de tipo int que se busca en el arbol
	 */
	public Boolean buscar(/*NodoSimple raiz, */int info){
		NodoSimple reco = raiz;
        while (reco!=null) {
            if (info == reco.getInfo())
                return true;
            else
                if (info>reco.getInfo())
                    reco=reco.getDerNodo();
                else
                    reco=reco.getIzqNodo();
        }
        return false;
		/*if(raiz == null){
			//System.out.println("El arbol esta vacio >:V");
			//return "No";
		}else{*/
		/*if(info == raiz.getInfo()){
			System.out.println("Si lo encontre");
			return "Si";
		}else{
			if(info < raiz.getInfo()){
				buscar(raiz.getIzqNodo(),info);
			}else{
			buscar(raiz.getDerNodo(),info);
			}
		}
		}
		return "No";*/
		/*{
			NodoSimple otraRaiz= this.raiz;
			 while (otraRaiz.getInfo() != info) {
				             if (info < otraRaiz.getInfo()) {
				            	 otraRaiz = otraRaiz.getIzqNodo();
				             } else {
				            	 otraRaiz = otraRaiz.getDerNodo();
				             }
				             if (otraRaiz == null)
				                 return null;
				         }
				         return otraRaiz/*.getInformacion();
		}*/
	}
	/**
	 * Metodo recursivo que permite quitar un nodo del arbol binario y reacomodar el arbol para que no se desbalancee
	 * @param raiz Nodo raiz del arbol
	 * @param info Dato de tipo int que se quiere borrar
	 */
	
	public void borrar(NodoSimple raiz, int info){
		if(info == raiz.getInfo()){
			if(info < this.raiz.getInfo()){
				NodoSimple aux = raiz;
				if(raiz.getIzqNodo() != null && raiz.getIzqNodo().getInfo() != -999){
					aux = raiz.getIzqNodo();
				}
			while(aux.getDerNodo() != null && aux.getDerNodo().getInfo() != -999){
				aux = aux.getDerNodo();
			}
			raiz.setInfo(aux.getInfo());
			aux.setInfo(-999);
			}
			if(info > this.raiz.getInfo()){
				NodoSimple aux1 = raiz;
				if(raiz.getDerNodo() != null && raiz.getDerNodo().getInfo() != -999){
				aux1 = raiz.getDerNodo();
				}
				while(aux1.getIzqNodo() != null && aux1.getIzqNodo().getInfo() != -999){
					aux1 = aux1.getIzqNodo();
				}
				raiz.setInfo(aux1.getInfo());
				aux1.setInfo(-999);
			}
			if(info == this.raiz.getInfo()){
				if(raiz.getIzqNodo() != null && raiz.getIzqNodo().getInfo() != -999){
					NodoSimple aux2 = raiz.getIzqNodo();
					while(aux2.getDerNodo() != null && aux2.getDerNodo().getInfo() != -999){
						aux2 = aux2.getDerNodo();
					}
					raiz.setInfo(aux2.getInfo());
					aux2.setInfo(-999);
				}
			}
		}
		else{
			if(info < raiz.getInfo()){
				borrar(raiz.getIzqNodo(),info);
			}else{
				borrar(raiz.getDerNodo(),info);
			}
		}
	}
}