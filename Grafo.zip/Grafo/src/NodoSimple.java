
//Proyecto Matriz y lista de adyacencia 
//Grupo 400 Biomedica
//Jose Angel Armendariz Martinez
//16/05/2017
//Laura Marina Bernal Zavala

/** Clase NodoSimple modela un tipo de dato para una estructura din�mica.
 * Tiene informacion y una referencia al siguiente nodo en la estructura.
 * @author JoseAngel
 *
 */
public class NodoSimple{
	/** La clase Nodo representa la informacion que guarda una estructura de datos
	 * con dos atributo de referencia que ligan a la informacion de la derecha y/o izquierda de la raiz de un arbol
	 */
	
	private int info;
	private String informacion;
	private NodoSimple izqNodo;
	private NodoSimple derNodo;
	
	public NodoSimple(String informacion){
		this(informacion,null);
	}
	
	public NodoSimple(String informacion, NodoSimple siguiente){
		this.informacion = informacion;
		this.derNodo = siguiente;
	}
	/**Constructor que recibe la informacionn a almacenar 
	 * 
	 * @param info Informacion o dato de tipo int almacenado en el arbol
	 */
	
	public NodoSimple(int info){
		this.info = info;
	}
	
	public void setInformacion(String informacion){
		this.informacion = informacion;
	}
	/** Metodo que recibe la informacion o dato de tipo int que actualiza
	 * el contenido del nodo del arbol.
	 * @param info Informacion o dato de tipo int almanecado en el arbol
	 */
	
	public void setInfo(int info){
		this.info = info;
	}
	/**Metodo que recibe el nodo correspondiente al lado izquierdo del arbol actualizando la referencia del nodo actual
	 * 
	 * @param izqNodo Nodo del lado izquierdo
	 */
	
	public void setIzqNodo(NodoSimple izqNodo){
		this.izqNodo = izqNodo;
	}
	/**Metodo que recibe el nodo correspondiente al lado derecho del arbol actualizando la referencia del nodo actual
	 * 
	 * @param derNodo Nodo del lado derecho
	 */
	
	public void setDerNodo(NodoSimple derNodo){
		this.derNodo = derNodo;
	}
	
	public String getInformacion(){
		return this.informacion;
	}
	/** Metodo que regresa la informacion o dato de tipo int almacenada en un nodo
	 * 
	 * @return info Informacion o dato de tipo int almacenado en un nodo del arbol
	 */
	
	public int getInfo(){
		return this.info;
	}
	/**Metodo que regresa el nodo que se encuentra al lado izquierdo
	 * 
	 * @return izqNodo Nodo al lado izquierdo
	 */
	
	public NodoSimple getIzqNodo(){
		return this.izqNodo;
	}
	/**Metodo que regresa el nodo que se encuentra al lado derecho
	 * 
	 * @return derNodo Nodo al lado derecho
	 */
	
	public NodoSimple getDerNodo(){
		return this.derNodo;
	}
}
