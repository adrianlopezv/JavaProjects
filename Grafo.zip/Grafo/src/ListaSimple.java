//Proyecto Matriz y lista de adyacencia 
//Grupo 400 Biomedica
//Jose Angel Armendariz Martinez
//16/05/2017
//Laura Marina Bernal Zavala

/**Clase ListaSimple modela un tipo de dato para una estructura din�mica.
 * Tiene un nodoRaiz que es de tipo NodoSimple.
 * 
 * @author JoseAngel
 *
 */
public class ListaSimple{
	/**
	 * La clase ListaSimple tiene como unico atributo a nodoRaiz el cual siempre va a 
	 * ser el inicio de la lista.
	 */

	private NodoSimple nodoRaiz;
	/**
	 * Constructor que recibe el nodo inicial de la lista.
	 * @param nodoRaiz Nodo de tipo NodoSimple el cual contiene la informacion del primer nodo de la lista
	 */
	
	public ListaSimple(NodoSimple nodoRaiz){
		this.nodoRaiz = nodoRaiz;
	}
	
	public NodoSimple getRaiz(){
		return this.nodoRaiz;
	}
	
	/**
	 * Metodo que recibe el nombre introducido por el usuario en el test, recorre un nodo auxiliar 
	 * para encontrar el final de la lista y colocar la informacion al final de la lista.
	 * @param informacion Informacion o dato de tipo String que introduce el usuario en el test.
	 */
	
	public void insercionAlFinal(String informacion){
		NodoSimple nodo = new NodoSimple(informacion);
		NodoSimple nodoAux = nodoRaiz;
		while(nodoAux.getDerNodo()!=null){
			nodoAux = nodoAux.getDerNodo();
		}
		nodoAux.setDerNodo(nodo);
	}
	/**
	 * Metodo toString que le indica al programa como imprimir los objetos del tipo ListaSimple
	 */

	public String toString(){
		NodoSimple nodoAux = nodoRaiz;
		String a = " "; 
		while(nodoAux.getDerNodo()!=null){
			a = a.concat(" " + nodoAux.getInformacion() + " ");
			nodoAux = nodoAux.getDerNodo();
		}
		a = a.concat(" " + nodoAux.getInformacion() + " ");
		return a;
	}
}
