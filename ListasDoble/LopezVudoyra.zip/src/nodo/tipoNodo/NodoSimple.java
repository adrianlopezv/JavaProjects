
package nodo.tipoNodo;
import nodo.Nodo;
public class NodoSimple extends Nodo
{
    public NodoSimple(String info)
    {
    super(info);
    }
}
