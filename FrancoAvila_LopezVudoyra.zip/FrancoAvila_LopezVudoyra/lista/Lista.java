package lista;

public interface Lista {
    
    public void crearLista();
    public void buscarNodo();
    public void borrarNodo();
    public String[][] imprimirLista();
    
}